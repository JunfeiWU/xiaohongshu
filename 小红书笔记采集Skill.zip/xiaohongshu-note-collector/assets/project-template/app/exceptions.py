class CollectorError(RuntimeError):
    """Base collector exception."""


class LoginRequiredError(CollectorError):
    pass


class PageStructureChangedError(CollectorError):
    pass


class AccessRestrictedError(CollectorError):
    pass


class NoteParseError(CollectorError):
    pass

