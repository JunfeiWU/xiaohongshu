from pathlib import Path


def profile_description(profile_dir: Path) -> str:
    """Return a display-only description; session files are never read by the app."""
    return f"持久化浏览器目录：{profile_dir}"

