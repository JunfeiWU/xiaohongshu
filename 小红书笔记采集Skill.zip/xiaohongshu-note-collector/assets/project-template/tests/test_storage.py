from datetime import datetime, timezone

from app.models.note import NoteRecord
from app.models.task import TaskStatus
from app.storage.sqlite_repo import SQLiteRepository


def make_note(title: str, like_count: int | None = None) -> NoteRecord:
    return NoteRecord(
        keyword="AI论文",
        rank=1,
        note_id="abc123",
        note_url="https://www.xiaohongshu.com/explore/abc123",
        title=title,
        like_count=like_count,
        crawl_time=datetime.now(timezone.utc),
    )


def test_repository_upserts_same_keyword_and_note(tmp_path):
    with SQLiteRepository(tmp_path / "app.db") as repository:
        task_id = repository.create_task("AI论文", 10, "fast")
        repository.save_note(make_note("旧标题", 10))
        repository.save_note(make_note("新标题", 20))
        repository.finish_task(task_id, TaskStatus.COMPLETED, 1)

        count = repository.connection.execute("SELECT COUNT(*) FROM notes").fetchone()[0]
        row = repository.connection.execute(
            "SELECT title, like_count FROM notes"
        ).fetchone()
        task = repository.connection.execute(
            "SELECT status, result_count FROM search_tasks WHERE id = ?", (task_id,)
        ).fetchone()

    assert count == 1
    assert tuple(row) == ("新标题", 20)
    assert tuple(task) == ("completed", 1)

