from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from app.models.note import NoteRecord


def test_note_record_allows_missing_optional_fields():
    note = NoteRecord(
        keyword="AI论文",
        rank=1,
        note_url="https://www.xiaohongshu.com/explore/abc123",
        crawl_time=datetime.now(timezone.utc),
    )
    assert note.author_name is None
    assert note.like_count is None


def test_note_rank_must_be_positive():
    with pytest.raises(ValidationError):
        NoteRecord(
            keyword="AI论文",
            rank=0,
            note_url="https://www.xiaohongshu.com/explore/abc123",
            crawl_time=datetime.now(timezone.utc),
        )

