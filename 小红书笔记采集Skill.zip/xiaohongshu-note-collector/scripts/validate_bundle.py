#!/usr/bin/env python3
"""Validate the bundled collector without opening a browser or accessing a site."""

from __future__ import annotations

import compileall
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TEMPLATE = ROOT / "assets" / "project-template"
REQUIRED = (
    "main.py",
    "requirements.txt",
    "config/settings.py",
    "config/selectors.py",
    "app/browser/manager.py",
    "app/search/search_service.py",
    "app/note/note_service.py",
    "app/storage/sqlite_repo.py",
    "tests/test_storage.py",
)


def main() -> int:
    missing = [name for name in REQUIRED if not (TEMPLATE / name).is_file()]
    if missing:
        print("Missing template files:", *missing, sep="\n- ")
        return 1
    if not compileall.compile_dir(TEMPLATE, quiet=1):
        return 1

    try:
        result = subprocess.run(
            [sys.executable, "-m", "pytest", "-q"],
            cwd=TEMPLATE,
            check=False,
        )
    except OSError as exc:
        print(f"Could not execute tests: {exc}")
        return 1
    if result.returncode != 0:
        print("Install the template requirements into the active environment, then retry.")
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())

