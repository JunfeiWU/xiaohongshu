from app.browser.manager import BrowserManager


async def wait_for_manual_login(browser: BrowserManager) -> None:
    """Compatibility wrapper that keeps login policy outside CLI code."""
    await browser.ensure_manual_login()

