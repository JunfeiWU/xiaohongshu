import pytest

from app.utils.count_parser import parse_count


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("123", 123),
        ("1,234", 1234),
        ("1.2万", 12000),
        ("3万", 30000),
        ("2.5千", 2500),
        ("1.1w", 11000),
        (None, None),
        ("", None),
        ("赞", None),
    ],
)
def test_parse_count(raw, expected):
    assert parse_count(raw) == expected

