"""Centralized selector fallbacks.

Xiaohongshu changes its markup regularly. Business code should only depend on
these semantic groups and tolerate every individual selector being absent.
"""

LOGIN_REQUIRED = (
    "text=扫码登录",
    "text=手机号登录",
    "text=登录后查看更多内容",
    "text=登录后查看搜索结果",
    "#login-btn",
    "[class*='login-container']",
    "[class*='login-modal']",
)

LOGGED_IN_MARKERS = (
    "[class*='side-bar'] a[href*='/user/profile/']",
)

SEARCH_CARDS = (
    "section.note-item",
    "article:has(a[href*='/explore/'])",
    "div.note-item",
)

NOTE_LINKS = (
    "a[href*='/explore/']",
    "a[href*='/discovery/item/']",
    "a[href*='/search_result/']",
)

CARD_TITLE = (
    "a.title span",
    "a.title",
    "[class*='title']",
    "img[alt]",
)

CARD_AUTHOR = (
    "a[href*='/user/profile/'] [class*='name']",
    "a[href*='/user/profile/'] span",
    "[class*='author'] [class*='name']",
)

CARD_LIKE = (
    "[class*='like'] [class*='count']",
    "span.count",
)

DETAIL_TITLE = (
    "#detail-title",
    "[class*='note-content'] [class*='title']",
    "h1",
)

DETAIL_AUTHOR = (
    "[class*='author-wrapper'] [class*='username']",
    "a[href*='/user/profile/'] [class*='name']",
    "a[href*='/user/profile/'] span",
)

DETAIL_LIKE = (
    "[class*='like-wrapper'] [class*='count']",
    "[class*='like'] [class*='count']",
    "[data-testid*='like'] [class*='count']",
)

DETAIL_COLLECT = (
    "[class*='collect-wrapper'] [class*='count']",
    "[class*='collect'] [class*='count']",
    "[data-testid*='collect'] [class*='count']",
)

DETAIL_COMMENT = (
    "[class*='chat-wrapper'] [class*='count']",
    "[class*='comment'] [class*='count']",
    "[data-testid*='comment'] [class*='count']",
)

DETAIL_PUBLISH_TIME = (
    "[class*='publish-time']",
    "[class*='bottom-container'] [class*='date']",
    "[class*='note-content'] [class*='date']",
    "time",
)

RISK_TEXTS = (
    "安全验证",
    "请完成验证",
    "滑块验证",
    "图形验证码",
    "访问频繁",
    "访问受限",
    "账号异常",
    "网络环境存在风险",
    "操作频繁",
)
