from __future__ import annotations

from collections.abc import Iterable

from playwright.async_api import Locator, Page


async def first_text(root: Page | Locator, selectors: Iterable[str]) -> str | None:
    for selector in selectors:
        try:
            locator = root.locator(selector).first
            if await locator.count() and await locator.is_visible():
                text = (await locator.inner_text()).strip()
                if text:
                    return text
        except Exception:
            continue
    return None


async def first_attribute(
    root: Page | Locator, selectors: Iterable[str], attribute: str
) -> str | None:
    for selector in selectors:
        try:
            locator = root.locator(selector).first
            if await locator.count():
                value = await locator.get_attribute(attribute)
                if value and value.strip():
                    return value.strip()
        except Exception:
            continue
    return None

