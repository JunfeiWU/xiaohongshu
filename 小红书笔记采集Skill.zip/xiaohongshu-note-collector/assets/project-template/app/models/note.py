from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class SearchResult(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    rank: int = Field(ge=1)
    note_url: str
    note_id: str | None = None
    title: str | None = None
    author_name: str | None = None
    like_count_raw: str | None = None


class NoteRecord(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    keyword: str
    rank: int = Field(ge=1)
    note_id: str | None = None
    note_url: str
    title: str | None = None
    author_name: str | None = None
    like_count: int | None = Field(default=None, ge=0)
    collect_count: int | None = Field(default=None, ge=0)
    comment_count: int | None = Field(default=None, ge=0)
    like_count_raw: str | None = None
    collect_count_raw: str | None = None
    comment_count_raw: str | None = None
    publish_time: datetime | None = None
    crawl_time: datetime

