from __future__ import annotations

import logging

from app.browser.manager import BrowserManager
from app.models.note import NoteRecord
from app.note.note_parser import enrich_from_detail_page


logger = logging.getLogger(__name__)


class NoteService:
    def __init__(self, browser: BrowserManager) -> None:
        self.browser = browser

    async def enrich_note(self, note: NoteRecord) -> NoteRecord:
        page = await self.browser.get_page()
        logger.info("解析详情：第 %d 篇 %s", note.rank, note.note_url)
        await page.goto(note.note_url, wait_until="domcontentloaded")
        await self.browser.action_delay()
        await self.browser.check_access_restriction()
        return await enrich_from_detail_page(page, note)

