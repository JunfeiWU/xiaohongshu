from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

import pandas as pd

from app.models.note import NoteRecord


def export_csv(records: list[NoteRecord], keyword: str, export_dir: Path) -> Path:
    export_dir.mkdir(parents=True, exist_ok=True)
    safe_keyword = re.sub(r"[^\w\u4e00-\u9fff-]+", "_", keyword).strip("_") or "search"
    output = export_dir / f"{datetime.now():%Y%m%d_%H%M%S}_{safe_keyword}.csv"
    columns = list(NoteRecord.model_fields)
    rows = [record.model_dump(mode="json") for record in records]
    pd.DataFrame(rows, columns=columns).to_csv(output, index=False, encoding="utf-8-sig")
    return output

