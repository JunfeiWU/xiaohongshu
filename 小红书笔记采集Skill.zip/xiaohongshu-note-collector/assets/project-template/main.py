from __future__ import annotations

import argparse
import asyncio
import logging
from datetime import datetime

from app.browser import BrowserManager
from app.exceptions import AccessRestrictedError
from app.models.note import NoteRecord, SearchResult
from app.models.task import TaskStatus
from app.note import NoteService
from app.search import XiaohongshuSearchService
from app.storage import SQLiteRepository, export_csv
from app.utils.count_parser import parse_count
from app.utils.debug_snapshot import save_debug_snapshot
from app.utils.logger import configure_logging
from config.settings import settings


logger = logging.getLogger(__name__)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="人工登录后，低频采集小红书搜索结果并保存 CSV/SQLite。"
    )
    parser.add_argument("--keyword", required=True, help="搜索关键词")
    parser.add_argument("--limit", type=int, default=20, help="最多采集篇数，默认 20，硬上限 50")
    parser.add_argument("--mode", choices=("fast", "full"), default="fast",
                        help="fast 仅搜索页；full 串行访问详情页")
    parser.add_argument("--keep-browser-open", action="store_true",
                        help="任务完成后保留 Chromium，直到用户手动关闭窗口")
    return parser.parse_args()


def validate_args(args: argparse.Namespace) -> None:
    args.keyword = args.keyword.strip()
    if not args.keyword:
        raise SystemExit("--keyword 不能为空")
    if args.limit < 1 or args.limit > settings.max_limit:
        raise SystemExit(f"--limit 必须在 1 到 {settings.max_limit} 之间")


def to_record(keyword: str, item: SearchResult) -> NoteRecord:
    return NoteRecord(
        keyword=keyword,
        rank=item.rank,
        note_id=item.note_id,
        note_url=item.note_url,
        title=item.title,
        author_name=item.author_name,
        like_count=parse_count(item.like_count_raw),
        like_count_raw=item.like_count_raw,
        crawl_time=datetime.now().astimezone(),
    )


async def run(keyword: str, limit: int, mode: str, keep_browser_open: bool = False) -> int:
    settings.ensure_directories()
    records: list[NoteRecord] = []
    browser = BrowserManager(settings)

    with SQLiteRepository(settings.database_path) as repository:
        task_id = repository.create_task(keyword, limit, mode)
        status = TaskStatus.FAILED
        error_message: str | None = None
        try:
            await browser.start()
            await browser.ensure_manual_login()
            search_service = XiaohongshuSearchService(browser, settings)
            try:
                search_results = await search_service.search(keyword, limit)
            except AccessRestrictedError:
                for result in search_service.partial_results:
                    record = to_record(keyword, result)
                    repository.save_note(record)
                    records.append(record)
                page = await browser.get_page()
                paths = await save_debug_snapshot(page, settings.debug_dir, "search_stopped")
                logger.error("停机页面调试快照：%s / %s", *paths)
                raise
            except Exception:
                page = await browser.get_page()
                paths = await save_debug_snapshot(page, settings.debug_dir, "search_failed")
                logger.error("搜索页调试快照：%s / %s", *paths)
                raise

            note_service = NoteService(browser)
            for index, result in enumerate(search_results, start=1):
                record = to_record(keyword, result)
                if mode == "full":
                    try:
                        record = await note_service.enrich_note(record)
                    except AccessRestrictedError:
                        repository.save_note(record)
                        records.append(record)
                        raise
                    except Exception as exc:
                        logger.warning("第 %d 篇详情解析失败，保留搜索页字段并继续：%s", index, exc)
                        page = await browser.get_page()
                        paths = await save_debug_snapshot(page, settings.debug_dir,
                                                          f"note_{index}_failed")
                        logger.info("详情页调试快照：%s / %s", *paths)
                repository.save_note(record)
                records.append(record)
                logger.info("已保存 %d/%d", index, len(search_results))

            output = export_csv(records, keyword, settings.export_dir)
            logger.info("CSV 已导出：%s", output)
            status = TaskStatus.COMPLETED
            return 0
        except AccessRestrictedError as exc:
            status = TaskStatus.STOPPED
            error_message = str(exc)
            logger.error("%s", exc)
            if records:
                output = export_csv(records, keyword, settings.export_dir)
                logger.info("已导出停止前的 %d 条数据：%s", len(records), output)
            return 2
        except KeyboardInterrupt:
            status = TaskStatus.PARTIAL
            error_message = "用户取消"
            if records:
                export_csv(records, keyword, settings.export_dir)
            logger.warning("任务已取消，已有数据已保存")
            return 130
        except Exception as exc:
            error_message = str(exc)
            logger.exception("任务失败：%s", exc)
            if records:
                export_csv(records, keyword, settings.export_dir)
                status = TaskStatus.PARTIAL
            return 1
        finally:
            repository.finish_task(task_id, status, len(records), error_message)
            if keep_browser_open:
                try:
                    page = await browser.get_page()
                    if not page.is_closed():
                        logger.info("Chromium 将保持打开；手动关闭浏览器窗口后程序退出")
                        await page.wait_for_event("close", timeout=0)
                except Exception as exc:
                    logger.debug("等待浏览器关闭时结束：%s", exc)
            await browser.close()


def main() -> int:
    configure_logging()
    args = parse_args()
    validate_args(args)
    return asyncio.run(run(args.keyword, args.limit, args.mode, args.keep_browser_open))


if __name__ == "__main__":
    raise SystemExit(main())
