from __future__ import annotations

import re
from datetime import datetime, timedelta


def parse_publish_time(value: str | None, now: datetime | None = None) -> datetime | None:
    if not value or not value.strip():
        return None
    now = now or datetime.now().astimezone()
    text = value.strip().split(" · ")[0].strip()

    if text == "刚刚":
        return now
    if text.startswith("昨天"):
        time_match = re.search(r"(\d{1,2}):(\d{2})", text)
        result = now - timedelta(days=1)
        return result.replace(hour=int(time_match.group(1)) if time_match else 0,
                              minute=int(time_match.group(2)) if time_match else 0,
                              second=0, microsecond=0)

    relative = re.search(r"(\d+)\s*(分钟|小时|天)前", text)
    if relative:
        amount = int(relative.group(1))
        unit = relative.group(2)
        delta = {"分钟": timedelta(minutes=amount),
                 "小时": timedelta(hours=amount),
                 "天": timedelta(days=amount)}[unit]
        return now - delta

    cleaned = text.replace("年", "-").replace("月", "-").replace("日", "")
    match = re.search(r"(?:(\d{4})-)?(\d{1,2})-(\d{1,2})(?:\s+(\d{1,2}):(\d{2}))?", cleaned)
    if not match:
        return None
    year = int(match.group(1) or now.year)
    try:
        result = now.replace(year=year, month=int(match.group(2)), day=int(match.group(3)),
                             hour=int(match.group(4) or 0), minute=int(match.group(5) or 0),
                             second=0, microsecond=0)
        if match.group(1) is None and result > now + timedelta(days=1):
            result = result.replace(year=year - 1)
        return result
    except ValueError:
        return None

