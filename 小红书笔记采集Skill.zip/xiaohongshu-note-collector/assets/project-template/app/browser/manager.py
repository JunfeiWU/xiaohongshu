from __future__ import annotations

import asyncio
import logging
import random
import time

from playwright.async_api import BrowserContext, Page, Playwright, async_playwright

from app.exceptions import AccessRestrictedError, LoginRequiredError
from config import selectors
from config.settings import Settings


logger = logging.getLogger(__name__)


class BrowserManager:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._playwright: Playwright | None = None
        self._context: BrowserContext | None = None
        self._page: Page | None = None

    async def start(self) -> None:
        self.settings.ensure_directories()
        self._playwright = await async_playwright().start()
        self._context = await self._playwright.chromium.launch_persistent_context(
            user_data_dir=str(self.settings.profile_dir),
            headless=False,
            viewport={"width": 1440, "height": 960},
            locale="zh-CN",
        )
        self._context.set_default_timeout(self.settings.page_timeout_ms)
        pages = self._context.pages
        self._page = pages[0] if pages else await self._context.new_page()
        logger.info("浏览器已启动（独立的本地持久化登录目录）")

    async def get_page(self) -> Page:
        if self._page is None:
            raise RuntimeError("BrowserManager.start() must be called first")
        return self._page

    async def close(self) -> None:
        try:
            if self._context is not None:
                await self._context.close()
        finally:
            if self._playwright is not None:
                await self._playwright.stop()
            self._context = None
            self._playwright = None
            self._page = None
            logger.info("浏览器已关闭")

    async def is_logged_in(self) -> bool:
        page = await self.get_page()
        if await self._any_visible(page, selectors.LOGIN_REQUIRED):
            return False
        return await self._any_visible(page, selectors.LOGGED_IN_MARKERS)

    async def ensure_manual_login(self) -> None:
        page = await self.get_page()
        await page.goto(self.settings.base_url, wait_until="domcontentloaded")
        await self.check_access_restriction()
        if await self.is_logged_in():
            logger.info("检测到有效登录状态")
            return

        logger.warning("请在打开的浏览器中人工完成小红书登录；程序不会保存用户名或密码")
        deadline = time.monotonic() + self.settings.login_timeout_seconds
        while time.monotonic() < deadline:
            await asyncio.sleep(2)
            await self.check_access_restriction()
            if await self.is_logged_in():
                logger.info("登录成功，继续执行任务")
                return
        raise LoginRequiredError("等待人工登录超时，请重新运行后在浏览器内完成登录")

    async def check_access_restriction(self) -> None:
        page = await self.get_page()
        try:
            body_text = (await page.locator("body").inner_text(timeout=3_000))[:20_000]
        except Exception:
            return
        matched = next((text for text in selectors.RISK_TEXTS if text in body_text), None)
        if matched:
            raise AccessRestrictedError(
                f"页面出现“{matched}”，任务已停止；请在浏览器中人工处理后再运行"
            )

    async def action_delay(self) -> None:
        await asyncio.sleep(random.uniform(
            self.settings.min_action_delay_seconds,
            self.settings.max_action_delay_seconds,
        ))

    @staticmethod
    async def _any_visible(page: Page, candidates: tuple[str, ...]) -> bool:
        for selector in candidates:
            try:
                locator = page.locator(selector).first
                if await locator.count() and await locator.is_visible():
                    return True
            except Exception:
                continue
        return False

    async def __aenter__(self) -> "BrowserManager":
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:  # type: ignore[no-untyped-def]
        await self.close()
