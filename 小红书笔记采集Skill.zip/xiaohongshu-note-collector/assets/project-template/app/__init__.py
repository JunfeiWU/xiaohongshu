"""Xiaohongshu research collector."""

