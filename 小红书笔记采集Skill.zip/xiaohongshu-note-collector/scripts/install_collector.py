#!/usr/bin/env python3
"""Install the bundled collector template into a new or empty directory."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
TEMPLATE = SKILL_ROOT / "assets" / "project-template"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", type=Path, required=True,
                        help="New or empty destination directory")
    return parser.parse_args()


def install(target: Path) -> None:
    target = target.expanduser().resolve()
    if target.exists() and any(target.iterdir()):
        raise SystemExit(f"Refusing to overwrite non-empty directory: {target}")
    if not TEMPLATE.is_dir():
        raise SystemExit(f"Bundled project template is missing: {TEMPLATE}")

    target.mkdir(parents=True, exist_ok=True)
    shutil.copytree(TEMPLATE, target, dirs_exist_ok=True)
    for relative in ("data/exports", "data/debug"):
        directory = target / relative
        directory.mkdir(parents=True, exist_ok=True)
        (directory / ".gitkeep").touch()
    print(f"Installed Xiaohongshu collector to: {target}")
    print("Next: create .venv, install requirements.txt, and install Playwright Chromium.")


if __name__ == "__main__":
    install(parse_args().target)

