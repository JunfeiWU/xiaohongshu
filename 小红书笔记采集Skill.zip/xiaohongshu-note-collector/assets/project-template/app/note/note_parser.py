from __future__ import annotations

from datetime import datetime

from playwright.async_api import Page

from app.models.note import NoteRecord
from app.exceptions import NoteParseError
from app.utils.count_parser import parse_count
from app.utils.dom import first_text
from app.utils.time_parser import parse_publish_time
from config import selectors


async def enrich_from_detail_page(page: Page, note: NoteRecord) -> NoteRecord:
    title = await first_text(page, selectors.DETAIL_TITLE)
    author = await first_text(page, selectors.DETAIL_AUTHOR)
    like_raw = await first_text(page, selectors.DETAIL_LIKE)
    collect_raw = await first_text(page, selectors.DETAIL_COLLECT)
    comment_raw = await first_text(page, selectors.DETAIL_COMMENT)
    publish_raw = await first_text(page, selectors.DETAIL_PUBLISH_TIME)
    if not any((title, author, like_raw, collect_raw, comment_raw, publish_raw)):
        raise NoteParseError("详情页未显示笔记内容，可能已被重定向或页面结构已变化")
    updates = {
        "title": title or note.title,
        "author_name": author or note.author_name,
        "like_count_raw": like_raw or note.like_count_raw,
        "collect_count_raw": collect_raw,
        "comment_count_raw": comment_raw,
        "like_count": parse_count(like_raw or note.like_count_raw),
        "collect_count": parse_count(collect_raw),
        "comment_count": parse_count(comment_raw),
        "publish_time": parse_publish_time(publish_raw, datetime.now().astimezone()),
    }
    return note.model_copy(update=updates)
