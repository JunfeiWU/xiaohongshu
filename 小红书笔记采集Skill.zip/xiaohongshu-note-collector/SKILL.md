---
name: xiaohongshu-note-collector
description: Set up, run, test, and maintain a low-frequency Xiaohongshu (小红书) note collector that uses a visible persistent Chromium session with manual login and exports search results or note details to CSV and SQLite. Use when a user asks to install or operate a 小红书笔记采集/抓取工具, search a keyword and collect top N public notes, reuse a manual login, export titles/authors/likes/collections/comments/times, troubleshoot page selectors, or package this workflow for research. Do not use to bypass CAPTCHA, security verification, access controls, rate limits, account restrictions, or platform anti-abuse systems.
---

# 小红书笔记采集

部署并运行内置的 Python + Playwright 项目。仅采集用户登录后在正常网页中可见、且其有权使用的数据。

## 安全边界

- 只使用可见浏览器和人工登录；不读取、导出或传递 Cookie、密码、Profile 内容。
- 默认从 `--limit 5 --mode fast` 开始；单任务硬上限 50，保持串行低频访问。
- 遇到验证码、安全验证、访问频繁、访问受限或账号异常，立即停止并保留已有结果。不得尝试绕过。
- 不增加代理池、账号轮换、验证码识别、指纹隐藏、自动化特征伪装、签名逆向或私有接口调用。
- 向用户说明自动访问无法保证绝不触发平台安全机制，并提醒其遵守平台条款、隐私要求和适用法律。
- 不把 `data/browser_profile/`、数据库或用户抓取结果放进可分发包。

## 工作流

1. 确认用户要部署新项目，还是运行已有项目。
2. 部署新项目时，运行：

   ```bash
   python <skill-dir>/scripts/install_collector.py --target <目标目录>
   ```

   目标目录必须不存在或为空。不要覆盖用户已有文件。

3. 在目标目录创建 `.venv`，安装 `requirements.txt`，再运行 `python -m playwright install chromium`。如果依赖已经安装，跳过重复安装。
4. 首次实测只运行：

   ```bash
   .venv/bin/python main.py --keyword "<关键词>" --limit 5 --mode fast
   ```

5. 浏览器提示登录时，让用户亲自在该 Chromium 窗口完成登录。不要要求用户提供 Cookie、账号密码或会话文件。
6. 检查任务日志、最新 CSV 和 SQLite 的 `search_tasks` 状态。确认 5 条基础结果无错位后，才考虑 `full` 模式或扩大数量。
7. 用户明确要求浏览器保持打开时，加 `--keep-browser-open`。任务完成后进程会等待用户手动关闭窗口。不要主动终止该进程。
8. 交付时报告关键词、条数、模式、输出文件绝对路径、缺失字段和是否出现风险提示。

## 模式选择

- 使用 `fast` 读取搜索结果页的排名、标题、作者、链接和点赞。优先选择，访问量最低。
- 使用 `full` 串行进入详情页，尝试补齐收藏、评论和发布时间。只有 fast 验收通过且用户确实需要详情字段时使用。
- 如果直接访问详情 URL 被重定向回首页，改为从搜索结果页卡片点击进入；不要循环重试 URL。

## 浏览器生命周期

- CLI 默认在任务结束时关闭它自己启动的 Chromium。
- 若用户说“不要关闭 Chromium/保留网站”，使用 `--keep-browser-open`。
- 同一个持久化 Profile 不能同时被两个 Playwright 进程占用。检测到占用时，不要启动第二个 CLI；优先继续操作现有窗口，或请用户关闭后重启。
- Safari、普通 Chrome 与项目 Chromium 的登录状态互不共享。用户必须在项目弹出的 Chromium 中登录一次。

## 验证与维护

- 运行 `pytest -q` 验证计数、时间、URL、模型和数据库逻辑。
- 运行 `<skill-dir>/scripts/validate_bundle.py` 检查 Skill 内置模板。
- 搜索页肉眼有内容但解析为 0 时，检查 `data/debug/` 最新 PNG/HTML，并只修改 `config/selectors.py` 或对应 Parser。
- 某字段缺失时允许留空；不要因单字段失败丢弃整篇笔记。
- 详情页没有任何笔记字段时应视为解析失败，而不是成功。
- 字段定义、数据库结构及常见故障见 [references/schema-and-troubleshooting.md](references/schema-and-troubleshooting.md)。仅在检查字段或排障时读取该文件。

## 内置资源

- `assets/project-template/`：可复制的完整采集项目源码和测试。
- `scripts/install_collector.py`：安全部署项目模板，不覆盖非空目录。
- `scripts/validate_bundle.py`：检查模板结构、语法与测试。

