from app.models.note import NoteRecord, SearchResult

__all__ = ["NoteRecord", "SearchResult"]

