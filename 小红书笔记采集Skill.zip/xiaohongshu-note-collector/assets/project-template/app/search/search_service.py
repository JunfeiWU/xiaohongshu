from __future__ import annotations

import logging
from urllib.parse import quote

from playwright.async_api import Locator, Page

from app.browser.manager import BrowserManager
from app.exceptions import PageStructureChangedError
from app.models.note import SearchResult
from app.search.search_parser import parse_bare_link, parse_search_card
from config import selectors
from config.settings import Settings


logger = logging.getLogger(__name__)


class XiaohongshuSearchService:
    def __init__(self, browser: BrowserManager, settings: Settings) -> None:
        self.browser = browser
        self.settings = settings
        self.partial_results: list[SearchResult] = []

    async def search(self, keyword: str, limit: int) -> list[SearchResult]:
        self.partial_results = []
        page = await self.browser.get_page()
        url = f"{self.settings.base_url}/search_result?keyword={quote(keyword)}&source=web_search_result_notes"
        logger.info("搜索关键词：%s", keyword)
        await page.goto(url, wait_until="domcontentloaded")
        await self.browser.action_delay()
        await self.browser.check_access_restriction()

        results: list[SearchResult] = []
        seen: set[str] = set()
        stable_rounds = 0

        for scroll_index in range(self.settings.max_scrolls + 1):
            before = len(results)
            cards = await self._find_cards(page)
            if await cards.count():
                for index in range(await cards.count()):
                    parsed = await parse_search_card(cards.nth(index), len(results) + 1,
                                                     self.settings.base_url)
                    self._append_unique(parsed, results, seen, limit)
                    if len(results) >= limit:
                        break
            else:
                links = page.locator(", ".join(selectors.NOTE_LINKS))
                for index in range(await links.count()):
                    parsed = await parse_bare_link(links.nth(index), len(results) + 1,
                                                   self.settings.base_url)
                    self._append_unique(parsed, results, seen, limit)
                    if len(results) >= limit:
                        break

            logger.info("当前已找到 %d 篇有效笔记", len(results))
            self.partial_results = list(results)
            if len(results) >= limit:
                break
            stable_rounds = stable_rounds + 1 if len(results) == before else 0
            if stable_rounds >= self.settings.stable_scroll_rounds:
                break
            if scroll_index < self.settings.max_scrolls:
                await page.mouse.wheel(0, 900)
                await self.browser.action_delay()
                await self.browser.check_access_restriction()

        if not results:
            body = await page.locator("body").inner_text()
            if "暂无" in body or "没有找到" in body:
                return []
            raise PageStructureChangedError(
                "搜索页未解析到笔记。已保存调试快照，请优先检查 config/selectors.py"
            )
        self.partial_results = results[:limit]
        return self.partial_results

    @staticmethod
    async def _find_cards(page: Page) -> Locator:
        return page.locator(", ".join(selectors.SEARCH_CARDS))

    @staticmethod
    def _append_unique(
        item: SearchResult | None,
        results: list[SearchResult],
        seen: set[str],
        limit: int,
    ) -> None:
        if item is None or len(results) >= limit:
            return
        key = item.note_id or item.note_url
        if key in seen:
            return
        seen.add(key)
        item.rank = len(results) + 1
        results.append(item)
