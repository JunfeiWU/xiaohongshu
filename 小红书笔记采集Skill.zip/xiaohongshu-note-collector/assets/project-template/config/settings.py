from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


@dataclass(frozen=True, slots=True)
class Settings:
    base_url: str = "https://www.xiaohongshu.com"
    profile_dir: Path = PROJECT_ROOT / "data" / "browser_profile"
    database_path: Path = PROJECT_ROOT / "data" / "app.db"
    export_dir: Path = PROJECT_ROOT / "data" / "exports"
    debug_dir: Path = PROJECT_ROOT / "data" / "debug"
    max_limit: int = 50
    login_timeout_seconds: int = 600
    page_timeout_ms: int = 30_000
    min_action_delay_seconds: float = 1.8
    max_action_delay_seconds: float = 3.8
    max_scrolls: int = 12
    stable_scroll_rounds: int = 3

    def ensure_directories(self) -> None:
        for path in (
            self.profile_dir,
            self.database_path.parent,
            self.export_dir,
            self.debug_dir,
        ):
            path.mkdir(parents=True, exist_ok=True)


settings = Settings()

