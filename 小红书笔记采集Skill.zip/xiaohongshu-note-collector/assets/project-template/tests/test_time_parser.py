from datetime import datetime, timedelta, timezone

from app.utils.time_parser import parse_publish_time


NOW = datetime(2026, 8, 12, 14, 30, tzinfo=timezone(timedelta(hours=8)))


def test_parse_full_chinese_date():
    assert parse_publish_time("2025年11月10日 17:21", NOW) == datetime(
        2025, 11, 10, 17, 21, tzinfo=NOW.tzinfo
    )


def test_parse_month_day_uses_current_year():
    assert parse_publish_time("08-10 12:00", NOW) == datetime(
        2026, 8, 10, 12, 0, tzinfo=NOW.tzinfo
    )


def test_future_month_day_rolls_to_previous_year():
    assert parse_publish_time("12-20", NOW) == datetime(
        2025, 12, 20, tzinfo=NOW.tzinfo
    )


def test_parse_relative_day():
    assert parse_publish_time("3天前", NOW) == NOW - timedelta(days=3)

