from __future__ import annotations

import hashlib
import sqlite3
from datetime import datetime
from pathlib import Path

from app.models.note import NoteRecord
from app.models.task import TaskStatus


SCHEMA = """
CREATE TABLE IF NOT EXISTS search_tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    keyword TEXT NOT NULL,
    requested_limit INTEGER NOT NULL,
    mode TEXT NOT NULL,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    status TEXT NOT NULL,
    result_count INTEGER NOT NULL DEFAULT 0,
    error_message TEXT
);

CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    keyword TEXT NOT NULL,
    rank INTEGER NOT NULL,
    identity_key TEXT NOT NULL,
    note_id TEXT,
    note_url TEXT NOT NULL,
    title TEXT,
    author_name TEXT,
    publish_time TEXT,
    like_count INTEGER,
    collect_count INTEGER,
    comment_count INTEGER,
    like_count_raw TEXT,
    collect_count_raw TEXT,
    comment_count_raw TEXT,
    crawl_time TEXT NOT NULL,
    UNIQUE(keyword, identity_key)
);

CREATE INDEX IF NOT EXISTS idx_notes_note_id ON notes(note_id);
CREATE INDEX IF NOT EXISTS idx_notes_crawl_time ON notes(crawl_time);
"""


class SQLiteRepository:
    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(path)
        self.connection.row_factory = sqlite3.Row
        self.connection.executescript(SCHEMA)
        self.connection.commit()

    def create_task(self, keyword: str, limit: int, mode: str) -> int:
        cursor = self.connection.execute(
            """INSERT INTO search_tasks
               (keyword, requested_limit, mode, started_at, status)
               VALUES (?, ?, ?, ?, ?)""",
            (keyword, limit, mode, datetime.now().astimezone().isoformat(),
             TaskStatus.RUNNING.value),
        )
        self.connection.commit()
        return int(cursor.lastrowid)

    def finish_task(
        self,
        task_id: int,
        status: TaskStatus,
        result_count: int,
        error_message: str | None = None,
    ) -> None:
        self.connection.execute(
            """UPDATE search_tasks
               SET finished_at = ?, status = ?, result_count = ?, error_message = ?
               WHERE id = ?""",
            (datetime.now().astimezone().isoformat(), status.value,
             result_count, error_message, task_id),
        )
        self.connection.commit()

    def save_note(self, note: NoteRecord) -> None:
        identity_key = note.note_id or hashlib.sha256(
            note.note_url.encode("utf-8")
        ).hexdigest()
        values = (
            note.keyword, note.rank, identity_key, note.note_id, note.note_url,
            note.title, note.author_name,
            note.publish_time.isoformat() if note.publish_time else None,
            note.like_count, note.collect_count, note.comment_count,
            note.like_count_raw, note.collect_count_raw, note.comment_count_raw,
            note.crawl_time.isoformat(),
        )
        self.connection.execute(
            """INSERT INTO notes (
                   keyword, rank, identity_key, note_id, note_url, title, author_name,
                   publish_time, like_count, collect_count, comment_count,
                   like_count_raw, collect_count_raw, comment_count_raw, crawl_time
               ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(keyword, identity_key) DO UPDATE SET
                   rank=excluded.rank,
                   note_url=excluded.note_url,
                   title=COALESCE(excluded.title, notes.title),
                   author_name=COALESCE(excluded.author_name, notes.author_name),
                   publish_time=COALESCE(excluded.publish_time, notes.publish_time),
                   like_count=COALESCE(excluded.like_count, notes.like_count),
                   collect_count=COALESCE(excluded.collect_count, notes.collect_count),
                   comment_count=COALESCE(excluded.comment_count, notes.comment_count),
                   like_count_raw=COALESCE(excluded.like_count_raw, notes.like_count_raw),
                   collect_count_raw=COALESCE(excluded.collect_count_raw, notes.collect_count_raw),
                   comment_count_raw=COALESCE(excluded.comment_count_raw, notes.comment_count_raw),
                   crawl_time=excluded.crawl_time""",
            values,
        )
        self.connection.commit()

    def close(self) -> None:
        self.connection.close()

    def __enter__(self) -> "SQLiteRepository":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:  # type: ignore[no-untyped-def]
        self.close()

