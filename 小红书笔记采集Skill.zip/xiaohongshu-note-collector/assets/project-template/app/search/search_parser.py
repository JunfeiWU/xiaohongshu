from __future__ import annotations

import re

from playwright.async_api import Locator

from app.models.note import SearchResult
from app.utils.dom import first_attribute, first_text
from app.utils.urls import absolute_url, canonical_note_url, extract_note_id
from config import selectors


_CARD_DATE_RE = re.compile(
    r"^(?:\d{1,2}[-月]\d{1,2}(?:日)?|\d+\s*(?:分钟|小时|天)前|昨天(?:\s+\d{1,2}:\d{2})?)$"
)


def clean_card_author(value: str | None) -> str | None:
    if not value:
        return None
    lines = [line.strip() for line in value.splitlines() if line.strip()]
    if len(lines) > 1 and _CARD_DATE_RE.match(lines[-1]):
        lines.pop()
    return " ".join(lines) or None


async def parse_search_card(card: Locator, rank: int, base_url: str) -> SearchResult | None:
    href = await first_attribute(card, selectors.NOTE_LINKS, "href")
    if not href:
        return None
    full_url = absolute_url(href, base_url)
    title = await first_text(card, selectors.CARD_TITLE)
    if not title:
        title = await first_attribute(card, selectors.CARD_TITLE, "alt")
    return SearchResult(
        rank=rank,
        note_url=canonical_note_url(full_url, base_url),
        note_id=extract_note_id(full_url),
        title=title,
        author_name=clean_card_author(await first_text(card, selectors.CARD_AUTHOR)),
        like_count_raw=await first_text(card, selectors.CARD_LIKE),
    )


async def parse_bare_link(link: Locator, rank: int, base_url: str) -> SearchResult | None:
    href = await link.get_attribute("href")
    if not href:
        return None
    full_url = absolute_url(href, base_url)
    title = (await link.get_attribute("title")) or (await link.get_attribute("aria-label"))
    if not title:
        image = link.locator("img[alt]").first
        if await image.count():
            title = await image.get_attribute("alt")
    return SearchResult(
        rank=rank,
        note_url=canonical_note_url(full_url, base_url),
        note_id=extract_note_id(full_url),
        title=title,
    )
