# 字段、存储与排障参考

## 字段

| 字段 | 含义 |
|---|---|
| `keyword` | 本次搜索关键词 |
| `rank` | 本次搜索结果顺序，从 1 开始 |
| `note_id` | 从公开笔记 URL 提取的标识 |
| `note_url` | 规范化笔记链接；保留打开页面必需的 `xsec` 参数 |
| `title` | 标题；页面未提供时为空 |
| `author_name` | 作者展示名，不包含列表卡片日期 |
| `like_count` / `_raw` | 标准化点赞整数及网页原始展示值 |
| `collect_count` / `_raw` | 标准化收藏整数及网页原始展示值 |
| `comment_count` / `_raw` | 标准化评论整数及网页原始展示值 |
| `publish_time` | 可解析时保存的带时区发布时间 |
| `crawl_time` | 本地采集时间 |

## SQLite

- `search_tasks`：任务关键词、请求上限、模式、开始/结束时间、状态、结果数、错误。
- `notes`：笔记字段。按 `keyword + note_id` 去重；无 ID 时使用规范化 URL 的 SHA-256。
- 每篇写入后立即提交，确保中途停机时保留已有结果。

## 常见问题

### Safari 已登录但 Chromium 提示登录

浏览器会话不共享。必须在项目打开的 Chromium 中人工登录一次。

### 提示 Profile 被占用

已有 Playwright Chromium 正在使用 `data/browser_profile/`。不要并发启动第二个进程；继续使用现有窗口或由用户手动关闭后再运行。

### 搜索结果为 0，但页面有卡片

查看 `data/debug/*search_failed.png` 和 HTML。先更新 `config/selectors.py` 中的 `SEARCH_CARDS`、`NOTE_LINKS`、`CARD_TITLE`、`CARD_AUTHOR`、`CARD_LIKE`，再做 5 条 fast 验证。

### 详情页回到首页

站点可能要求从带 `xsec_token` 的搜索结果链接进入。保持这些参数，或从搜索页点击卡片。不要反复直接访问 `/explore/{id}`。

### 详情流程“完成”但字段为空

详情 Parser 必须在所有目标字段都为空时抛出 `NoteParseError`。保存搜索页字段和调试快照，不能将空解析视为成功补齐。

### 出现验证或访问限制

立即停止。保存已有 SQLite/CSV 和快照，让用户人工检查。不得自动刷新、切换账号、换代理或尝试完成验证码。

