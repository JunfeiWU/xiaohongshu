from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

from playwright.async_api import Page


async def save_debug_snapshot(page: Page, debug_dir: Path, label: str) -> tuple[Path, Path]:
    debug_dir.mkdir(parents=True, exist_ok=True)
    safe_label = re.sub(r"[^A-Za-z0-9_-]+", "_", label)[:60]
    stem = f"{datetime.now():%Y%m%d_%H%M%S}_{safe_label}"
    html_path = debug_dir / f"{stem}.html"
    png_path = debug_dir / f"{stem}.png"
    html_path.write_text(await page.content(), encoding="utf-8")
    await page.screenshot(path=str(png_path), full_page=True)
    return html_path, png_path

