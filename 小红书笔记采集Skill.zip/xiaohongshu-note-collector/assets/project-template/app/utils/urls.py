from __future__ import annotations

import re
from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit, urlunsplit


_NOTE_ID_RE = re.compile(r"/(?:explore|discovery/item|search_result)/([A-Za-z0-9]+)")


def absolute_url(url: str, base_url: str) -> str:
    return urljoin(base_url, url)


def canonical_note_url(url: str, base_url: str) -> str:
    absolute = absolute_url(url, base_url)
    parts = urlsplit(absolute)
    # xsec parameters can be required to open a search result legitimately;
    # discard only unrelated tracking parameters.
    allowed = {"xsec_token", "xsec_source"}
    query = urlencode([(key, value) for key, value in parse_qsl(parts.query)
                       if key in allowed])
    return urlunsplit((parts.scheme or "https", parts.netloc,
                       parts.path.rstrip("/"), query, ""))


def extract_note_id(url: str) -> str | None:
    match = _NOTE_ID_RE.search(url)
    return match.group(1) if match else None
