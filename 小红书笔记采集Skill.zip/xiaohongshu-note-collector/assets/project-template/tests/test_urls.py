from app.utils.urls import canonical_note_url, extract_note_id
from app.search.search_parser import clean_card_author


def test_extract_note_id_from_supported_paths():
    assert extract_note_id("https://www.xiaohongshu.com/explore/abc123") == "abc123"
    assert extract_note_id("/search_result/def456?xsec_token=t") == "def456"


def test_canonical_url_keeps_required_xsec_and_drops_other_tracking():
    url = canonical_note_url(
        "/search_result/abc123?foo=bar&xsec_token=secret&xsec_source=pc_search",
        "https://www.xiaohongshu.com",
    )
    assert url == (
        "https://www.xiaohongshu.com/search_result/abc123"
        "?xsec_token=secret&xsec_source=pc_search"
    )


def test_clean_card_author_removes_display_date():
    assert clean_card_author("亡牌画手\n08-01") == "亡牌画手"
    assert clean_card_author("雾里观星\n5天前") == "雾里观星"
    assert clean_card_author("普通作者") == "普通作者"
