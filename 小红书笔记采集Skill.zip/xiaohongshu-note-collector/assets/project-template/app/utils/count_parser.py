from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP


_COUNT_RE = re.compile(r"([0-9]+(?:\.[0-9]+)?)\s*([万千wWkK]?)")
_MULTIPLIERS = {"": 1, "千": 1_000, "k": 1_000, "K": 1_000,
                "万": 10_000, "w": 10_000, "W": 10_000}


def parse_count(value: str | int | None) -> int | None:
    if value is None:
        return None
    if isinstance(value, int):
        return max(value, 0)
    normalized = value.strip().replace(",", "").replace("+", "")
    if not normalized or normalized in {"赞", "收藏", "评论", "--", "-"}:
        return None
    match = _COUNT_RE.search(normalized)
    if not match:
        return None
    try:
        number = Decimal(match.group(1)) * _MULTIPLIERS[match.group(2)]
        return int(number.quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    except (InvalidOperation, KeyError):
        return None

